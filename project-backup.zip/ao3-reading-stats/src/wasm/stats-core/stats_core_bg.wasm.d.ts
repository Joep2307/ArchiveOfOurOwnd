/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const histogram: (a: number, b: number, c: number, d: number) => [number, number];
export const summarize: (a: number, b: number) => [number, number];
export const __wbindgen_export_0: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
